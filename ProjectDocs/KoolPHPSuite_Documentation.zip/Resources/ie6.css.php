<?php 
	header('Content-type: text/css');
	$imgURL = $_GET["imgURL"];
?>

/*IE6 fix */
* html table.hack-ie{
	margin-top:0px;
	position:absolute;
	top:102px;
}

* html #main .show-it
{
	width:99%;
}

* html img.logo
{
	background:none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $imgURL;?>/kool_suite_demo_logo.png', sizingMethod='crop');
}


* html td.tl img
{
	background:none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $imgURL;?>/content_top_left.png', sizingMethod='crop');
}

* html td.tr img
{
	background:none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $imgURL;?>/content_top_right.png', sizingMethod='crop');
}

* html td.bl img
{
	background:none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $imgURL;?>/content_bottom_left.png', sizingMethod='crop');
}

* html td.br img
{
	background:none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $imgURL;?>/content_bottom_right.png', sizingMethod='crop');
}

* html img.KoolPHPSuite
{
	background:none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $imgURL;?>/KoolPHPSuite.png', sizingMethod='crop');
}
* html img.KoolAjax
{
	background:none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $imgURL;?>/KoolAjax.png', sizingMethod='crop');
}
* html img.KoolAutoComplete
{
	background:none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $imgURL;?>/KoolAutoComplete.png', sizingMethod='crop');
}
* html img.KoolComboBox
{
	background:none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $imgURL;?>/KoolComboBox.png', sizingMethod='crop');
}
* html img.KoolImageView
{
	background:none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $imgURL;?>/KoolImageView.png', sizingMethod='crop');
}
* html img.KoolSlideMenu
{
	background:none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $imgURL;?>/KoolSlideMenu.png', sizingMethod='crop');
}
* html img.KoolTabs
{
	background:none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $imgURL;?>/KoolTabs.png', sizingMethod='crop');
}
* html img.KoolTreeView
{
	background:none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $imgURL;?>/KoolTreeView.png', sizingMethod='crop');
}
* html img.KoolUploader
{
	background:none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $imgURL;?>/KoolUploader.png', sizingMethod='crop');
}

* html .control
{
	height:16px;
	background:none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $imgURL;?>/controls_line_btm_over_ie6.png', sizingMethod='crop');
}

* html .content-L #controls li.first
{
	display:block;
	height:31px;
	width:200px;
	background:none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $imgURL;?>/controls_line_btm_ie6.png', sizingMethod='crop');
}

* html .content-L #controls li a
{
	cursor:pointer;
	background:none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $imgURL;?>/controls_line_btm_ie6.png', sizingMethod='crop');
}

* html .content-L #controls li a:hover
{
	background:none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $imgURL;?>/controls_line_btm_over_ie6.png', sizingMethod='crop');
}
* html #main .component-title img{
	margin-bottom:0px;
}
* html img.download
{
	background:none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $imgURL;?>/download.png', sizingMethod='crop');
}
