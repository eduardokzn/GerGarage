<?php header("Location: Controls/KoolPHPSuite/index.php");?>
