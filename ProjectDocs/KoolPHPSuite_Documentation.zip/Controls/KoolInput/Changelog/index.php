<?php 
	header("Location: ../../KoolForm/Changelog/index.php");
?>