<?php 
	include "../../../Resources/show_changelog.php";
?>