KOOLHPSUITE DOCUMENTATION

1. INTALLATION GUIDE:
   a. Unzip the documentation zip file
   b. Copy the unzipped folder to php hosting.
   c. Start browsing the index.php

2. NOTICE
   a. Please always refer to the most updated documentation located at http://doc.koolphp.net