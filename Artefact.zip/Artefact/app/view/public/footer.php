<div class="container">

   <!-- 
    <span class="text-muted"> Copyright &copy; Conor O&#39;Reilly </span>
   --> 

</div>