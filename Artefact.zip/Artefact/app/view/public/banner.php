<!-- PUBLIC MENU -->

    <!-- MENU -->
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark fixed-top">

      <a class="navbar-brand" href="index.php">
        <img src="img/DarkAlien.png" alt="logo" style="width:60px;">
      </a> 
        
    </nav>           
        
