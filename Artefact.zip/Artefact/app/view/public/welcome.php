<div  id="intro" class="view aligner hm-black-strong">
        
    <div class="container full-bg-img box-dark">
        
        <h2 class="display-3 font-bold white-text margin-bottom-2">Ger's Garage</h2>
        <hr class="hr-light">
        <h4 class="white-text my-4">
            Your mechanic to motorbikes, cars, small vans and small buses

        </h4>
       <!--  
            <button type="button ml-2" 
            class="btn btn-outline-white"
            id="scrollit"
            >
                    Read More
                    --><!-- see icons https://mdbootstrap.com/content/icons-list/ --><!--
                    <i class="fa fa-arrow-circle-down ml-2"></i>
            </button>
        -->
    </div><!-- .full-bg-img -->
</div><!-- #intro -->   