<!-- THIS IS FOR HEAD -->

<meta charset="utf-8">

<title>Ger's Garage</title>

<meta name="description" content="Ger's Garage">
<meta name="author" content="Eduardo Kenji Zen Nakashima">
<meta name="keywords" content="PHP, Bootstrap">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- bootstrap 4 CSS loaded from CDN -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" 
integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">

<!-- for nice icons, they are in this font CSS fa calls them 
     https://www.w3schools.com/icons/fontawesome_icons_intro.asp
-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- your stylesheets here -->
<link href="css/styles.css" rel="stylesheet"/>
<link href="./css/ajaxStyles.css" rel="stylesheet"/>

<!-- javaScript used in page creation -->
<script type="text/javascript" src="js/turtles.js"></script>
<script type="text/javascript" src="js/AjaxCRUDStaffReview.js"></script>


<link rel="stylesheet" href="../_static/js/dojo/../dijit/themes/claro/claro.css">
<?php
    date_default_timezone_set('UTC');
?>