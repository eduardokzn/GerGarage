<div class="container">

   <!-- 
    <span class="text-muted"> Copyright &copy; Conor O&#39;Reilly </span>
    <span class="text-muted"> Copyright &copy; Eduardo Kenji Zen Nakashima </span>
   --> 

</div>